
# MAIN GUI FOR BINGO GENERATOR
# This program generates the gui to generate the bingo cards

from tkinter import *
from PIL import ImageTk,Image

from AdultBingoGenerator import GenAdultCard 
from KidBingoGenerator import GenKidCard

# When buttons are clicked these methods are called
def adultClick():
    GenAdultCard()

def kidClick():
    GenKidCard()


root = Tk()
root.title("Bingo Card Generator")

#Greater Vicotria Placemaking image
logoPng = ImageTk.PhotoImage(Image.open("VPMHeader.png"))
logoLabel = Label(image=logoPng)
logoLabel.grid(row=0,column=0)



root.geometry("750x200")
#root.resizable("false","false")

titleText = Label(root,
                  font = ("Avenir Next",32),
                  text= "LFL Bingo Card Generator")

instructText = Label(root, text= "Click the buttons below to generate a LFL Bingo Card!")

titleText.grid(row=0, column=1)
instructText.grid(row=1, column=1)

blankText = Label(root, text = "                 ")
blankText.grid(row=6,column=1)

adultButton = Button(root,text="Generate Adult Bingo Card", padx = 50, command = adultClick)
adultButton.grid(row=5, column=1)

kidButton = Button(root,text="Generate Kid Bingo Card", padx = 50, command=kidClick)
kidButton.grid(row=7, column=1)


root.mainloop()
